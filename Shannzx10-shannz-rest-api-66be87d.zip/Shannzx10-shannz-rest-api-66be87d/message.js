/** 
 * DannTeam
 * ig: @dannalwaysalone
*/

const author = 'Shannz'

msg = {
  paramurl: {
    status: false,
    creator: author,
    message: 'Masukkan Parameter URL!'
  },
  paramquery: {
    status: false,
    creator: author,
    message: 'Masukkan Parameter Query!'
  },
  nodata: {
    status: false,
    creator: author,
    message: 'Data tidak ditemukan!'
  }
}
